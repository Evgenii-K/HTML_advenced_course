<!doctype html>
<html>
<head>
<meta http-equiv="Cache-Control" content="no-cache">
<meta charset="utf-8">
<link rel="stylesheet" href="css/Base.css">
<link rel="stylesheet" href="css/fon.css">
<link rel="stylesheet" href="css/anim.css">
<title>Занятие №6 курса HTML5&amp;CSS</title>

</head>

<body>

<div id="header">
<header>  
  <div class="floatfigure">
  	<img src="pict/HTML5CSS3.png" width="80" alt="HTML & CSS">
</div>
<h1>HTML5 &amp; CSS</h1>
</header>
</div>
<nav>
	<a href="?url=index">Главная</a>
	<a href="?url=1erer">Обучение</a>
	<a href="?url=dop">Дополнительная информация</a>
	<a href="?url=cont">Контакты</a>
</nav>

<div id="content">

<article>
 <header>
  <small>   <time datetime="2016-06-16">Опубликовано 16 июня 2016</time>   </small>
  <h1>Урок 6. Анимация в CSS.</h1></header>
<figure class="floatfigure">
  	<img src="pict/HTMLCSS.png" width="100" alt="HTML&CSS">
<figcaption>HTML5 &amp; CSS</figcaption>
</figure>

  <p>&nbsp;</p>
</article>
<h2>CSS3 Анимация</h2>
<p>Для браузеров Chrome и Safari перед свойством требуется  добавить префикс -webkit.<br>
  Для создания анимации в CSS3 используется свойство  @keyframes.<br>
  Данное свойство представляет собой контейнер, в который  должны помещаться различные свойства оформления.</p>

<xmp id="scriptHTML">
@keyframes имяАнимации
{
from {CSS свойства} /* Оформление элемента перед началом анимации */
to {CSS свойства} /* Оформление элемента после завершения анимации */
}
</xmp>

<p>После того, как анимация была создана необходимо добавить к  элементу, который Вы хотите анимировать CSS3 свойство animation и указать в нем  имя анимации (1 значение) и время (2 значение), в течении которого она будет  выполняться.<br>
  Также Вы можете устанавливать количество повторов анимации  (3 значение).</p>
  
<xmp id="scriptHTML">
    @keyframes anim {
    from {margin-left:3px;}
    to {margin-left:500px;}
    }
    
    #wrap1 {
    animation:anim 4s 3;
    } 
</xmp>

<p>Полный листинг анимированной страницы представлен ниже.</p>
<div id="scriptHTML">
&lt;html&gt;<br>
&lt;style  type='text/css'&gt;
<xmp>
@keyframes anim{
    from {margin-left:3px;}
    to {margin-left:500px;}
    }
    @-moz-keyframes anim{
    from {margin-left:3px;}
    to {margin-left:500px;}
    }
    @-webkit-keyframes anim{
    from {margin-left:3px;}
    to {margin-left:500px;}
    }
    #wrap1{
    border:2px #000 solid;
    background-color:#7F0055;
    height:100px;
    width:100px;
    font-size:2em;
    animation:anim 4s 3;
    -webkit-animation:anim 4s 3;
    }
 </xmp>
&lt;/style&gt;<br>
    &lt;body&gt;<br>
    &lt;div id=&quot;wrap1&quot;&gt;&lt;/div&gt;<br>
    &lt;p&gt;Анимация повторится 3 раза.&lt;/p&gt;<br>
    &lt;/body&gt;<br>
    &lt;/html&gt;
</div>

<div class="demo clearfix">
<div id="wrap1"></div>
<p>Анимация повторится 3 раза.</p>
</div>
<h3><a name="_Toc454487472">Ход выполнения анимации</a></h3>
<p>Вы можете определять ход выполнения анимации не только с  помощью ключевых слов from и to (которые использовались в предыдущем примере),  но и с помощью %.</p>
<p>С помощью % Вы можете более точно контролировать ход  выполнения анимации, например можно указать, что определенный элемент в начале  анимации (0%) должен быть белым к середине (50%) должен окрашиваться в  оранжевый цвет, а к концу (100%) становиться черным.</p>
<p>&nbsp;</p>
<xmp id="scriptHTML">
@keyframes anim {
0% {margin-left:3px;margin-top:3px;background-color:#7F0055;}
30% {margin-left:3px;margin-top:250px;background-color:#7F0055;}
60% {margin-left:500px;margin-top:250px;background-color:black;}
100% {margin-left:3px;margin-top:3px;background-color:#7F0055;}
}

#wrap1 {
animation:anim 6s 3;
}

</xmp>
<div class="demo demoH clearfix">
<div id="wrap2" animation-duration: 2s></div>
</div>

<p>CSS3 свойства анимации</p>
<table border="1" cellspacing="0" cellpadding="0" width="633">
  <tr>
    <th width="191">Свойство</th>
    <th width="442">Описание</th>
  </tr>
  <tr>
    <td>@keyframes</td>
    <td width="442">Контейнер для определения анимации.</td>
  </tr>
  <tr>
    <td>animation</td>
    <td width="442">Позволяет задать все значения для настройки    выполнения анимации за одно определение.</td>
  </tr>
  <tr>
    <td>animation-name</td>
    <td width="442">Позволяет указать имя анимации.</td>
  </tr>
  <tr>
    <td>animation-duration</td>
    <td width="442">Позволяет задать скорость выполнения анимации в    секундах (<em>по умолчанию имеет значение 0</em>).</td>
  </tr>
  <tr>
    <td>animation-timing-function</td>
    <td width="442">Позволяет задать функцию смягчения отвечающую за    плавность выполнения анимации (<em>по умолчанию имеет значение ease</em>).</td>
  </tr>
  <tr>
    <td>animation-delay</td>
    <td width="442">Позволяет задать задержку перед началом выполнения    анимации (<em>по умолчанию имеет значение 0</em>).</td>
  </tr>
  <tr>
    <td>animation-iteration-count</td>
    <td width="442">Позволяет задать количество повторов анимации (<em>по    умолчанию имеет значение 1</em>).</td>
  </tr>
  <tr>
    <td>animation-direction</td>
    <td width="442">При значении alternate в нечетные разы (<em>1,3,5 ...</em>)    анимация будет проигрываться в нормальном, а в четные (<em>2,4,6 ...</em>) в    обратном порядке. По умолчанию данное свойство имеет значение normal, при    данном значении анимация всегда проигрывается в нормальном порядке.</td>
  </tr>
</table>
<h2>Длительность анимации animation-duration</h2>
<p>Свойство устанавливает длительность анимации. Не  наследуется. Значение по умолчанию 0.</p>
<table border="1" cellspacing="0" cellpadding="0" width="660">
  <tr>
    <th width="131" valign="top">Значения:</th>
    <th valign="top">Описание</th>
  </tr>
  <tr>
    <td width="131" valign="top"><p>время</p></td>
    <td valign="top"><p>Длительность анимации задается в секундах&nbsp;s&nbsp;или миллисекундах ms.</p></td>
  </tr>
  <tr>
    <td width="131" valign="top"><p>initial</p></td>
    <td valign="top"><p>Устанавливает значение свойства в значение по умолчанию.</p></td>
  </tr>
  <tr>
    <td width="131" valign="top"><p>inherit</p></td>
    <td valign="top"><p>Наследует значение свойства от родительского элемента.</p></td>
  </tr>
</table>
<p>Синтаксис</p>
<xmp id="scriptHTML">
      div 
      {
      -webkit-animation-duration: 2s;
      animation-duration: 2s;
      } 
</xmp>

<h2>Временная  функция animation-timing-function</h2>
<p>Свойство определяет изменение скорости от начала до конца  анимации с помощью временных функций. Задаётся при помощи ключевых слов или  кривой Безье cubic-bezier(x1, y1, x2, y2). Не наследуется.</p>
<table border="1" cellspacing="0" cellpadding="0" width="660">
  <tr>
    <th width="156" valign="top">Значения: </th>
    <th valign="top">Описание</th>
  </tr>
  <tr>
    <td width="156" valign="top"><p>ease</p></td>
    <td valign="top"><p>Функция по умолчанию, анимация начинается медленно, разгоняется быстро и    замедляется в конце. Соответствуетcubic-bezier(0.25,0.1,0.25,1).</p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>linear</p></td>
    <td valign="top"><p>Анимация происходит равномерно на протяжении всего времени, без    колебаний в скорости. Соответствует&nbsp;cubic-bezier(0,0,1,1).</p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>ease-in</p></td>
    <td valign="top"><p>Анимация начинается медленно, а затем плавно ускоряется в конце.    Соответствует&nbsp;cubic-bezier(0.42,0,1,1).</p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>ease-out</p></td>
    <td valign="top"><p>Анимация начинается быстро и плавно замедляется в конце.    Соответствует&nbsp;cubic-bezier(0,0,0.58,1).</p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>ease-in-out</p></td>
    <td valign="top"><p>Анимация медленно начинается и медленно заканчивается.    Соответствует&nbsp;cubic-bezier(0.42,0,0.58,1).</p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>cubic-bezier(x1, y1,    x2, y2)</p></td>
    <td valign="top"><p>Позволяет вручную установить значения от 0 до 1.&nbsp;<a href="http://roblaplaca.com/examples/bezierBuilder/" target="_blank">На этом сайте</a>&nbsp;вы сможете построить любую траекторию    скорости изменения анимации.</p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>step-start</p></td>
    <td valign="top"><p>Задаёт пошаговую анимацию, разбивая анимацию на отрезки, изменения    происходят в начале каждого шага. Эквивалентноsteps(1, start).</p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>step-end</p></td>
    <td valign="top"><p>Пошаговая анимация, изменения происходят в конце каждого шага.    Эквивалентно&nbsp;steps(1, end).</p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>steps(количество шагов,start|end)</p></td>
    <td valign="top"><p>Ступенчатая временная функция, которая принимает два параметра.    Количество шагов задается целым положительным числом. Второй параметр    необязательный, указывает момент, в котором начинается анимация. Со    значением&nbsp;start&nbsp;анимация начинается в начале каждого шага, со    значением&nbsp;end&nbsp;— в конце каждого шага с задержкой. Задержка    вычисляется как результат деления времени анимации на количество шагов. Если    второй параметр не указан, используется значение по умолчаниюend.</p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>initial</p></td>
    <td valign="top"><p>Устанавливает значение свойства в значение по умолчанию.</p></td>
  </tr>
  <tr>
    <td width="156" valign="top"><p>inherit</p></td>
    <td valign="top"><p>Наследует значение свойства от родительского элемента.</p></td>
  </tr>
</table>
<p>Синтаксис: </p>
<xmp id="scriptHTML">
-webkit-animation-timing-function: linear; 
animation-timing-function: linear;
</xmp>
<p>Пример анимации</p>
<div class="demo clearfix">
<div id="wrap3"></div>
</div>
<h2>Шаги анимации</h2>
<p>Элемент можно анимировать используя шаги, т.е. ступенчато.  (Примером может послужить секундная стрелка часов, которая сначала двигается, а  затем осуществляется задержка на 1 секунду, потом снова двигается и снова  задержка и т.д.) Шаги задаются  с помощью функции steps(). Ниже показан пример:</p>
<xmp id="scriptHTML">
	animation:anim4 6s steps(12) 3;
	-webkit-animation:anim4 6s steps(12) 3;
    
    /* Или */
    
	animation-timing-function: steps(12);
	-webkit-animation-timing-function: step(12);
</xmp>
<p>Теперь анимация будет проходить рывками.  Задержка между рывками в данном случае будет 500ms (6сек/12). Второй параметр функции steps указывает, будет ли  рывок выполняться сразу или после задержки.</p>

<div class="demo clearfix">
<div id="wrap4"></div>
</div>

<h2>Анимация с задержкой animation-delay</h2>
<p>Свойство игнорирует анимацию заданное количество времени,  что даёт возможность по отдельности запускать каждую анимацию. Отрицательная  задержка начинает анимацию с определенного момента внутри её цикла, т.е. со  времени, указанного в задержке. Это позволяет применять анимацию к нескольким  элементам со сдвигом фазы, изменяя лишь время задержки.</p>
<p>Чтобы анимация началась с середины, нужно задать  отрицательную задержку, равную половине времени, установленном в animation-duration.  Не наследуется.</p>
<table border="1" cellspacing="0" cellpadding="0" width="623">
  <tr>
    <th width="140" valign="top">Значения: </th>
    <th width="483" valign="top">Описание</th>
  </tr>
  <tr>
    <td width="140" valign="top"><p>время</p></td>
    <td width="483" valign="top"><p>Задержка анимации задается в    секундах&nbsp;s&nbsp;или миллисекундах&nbsp;ms. Значение по умолчанию&nbsp;0.</p></td>
  </tr>
  <tr>
    <td width="140" valign="top"><p>initial</p></td>
    <td width="483" valign="top"><p>Устанавливает значение свойства в    значение по умолчанию.</p></td>
  </tr>
  <tr>
    <td width="140" valign="top"><p>inherit</p></td>
    <td width="483" valign="top"><p>Наследует значение свойства от родительского    элемента.</p></td>
  </tr>
</table>
<p>Синтаксис:</p>
<xmp id="scriptHTML">
      -webkit-animation-delay: 2s; 
      animation-delay: 2s; 
</xmp>

<p> Пример анимаии </p>
<div class="demo clearfix">
<div id="wrap5"></div>
<div id="wrap6"></div>
<div id="wrap7"></div>
</div>

<h2>Повтор  анимации animation-iteration-count</h2>
<p>Свойство позволяет запустить анимацию несколько раз.  Значение 0 или любое отрицательное число удаляют анимацию из проигрывания. Не наследуется.</p>
<table border="1" cellspacing="0" cellpadding="0" width="623">
  <tr>
    <th width="131" valign="top">Значения: </th>
    <th width="492" valign="top">Описание</th>
  </tr>
  <tr>
    <td width="131" valign="top"><p>число</p></td>
    <td width="492" valign="top"><p>С помощью целого числа задается    количество повторов анимации. Значение по умолчанию&nbsp;1.</p></td>
  </tr>
  <tr>
    <td width="131" valign="top"><p>infinite</p></td>
    <td width="492" valign="top"><p>Анимация проигрывается бесконечно.</p></td>
  </tr>
  <tr>
    <td width="131" valign="top"><p>initial</p></td>
    <td width="492" valign="top"><p>Устанавливает значение свойства в    значение по умолчанию.</p></td>
  </tr>
  <tr>
    <td width="131" valign="top"><p>inherit</p></td>
    <td width="492" valign="top"><p>Наследует значение свойства от    родительского элемента.</p></td>
  </tr>
</table>
<p>Синтаксис:</p>
<xmp id="scriptHTML">
      -webkit-animation-iteration-count:    3; 
      animation-iteration-count:    3; 
</xmp>
<h2>Направление анимации animation-direction</h2>
<p>Свойство задает направление повтора анимации. Если анимация  повторяется только один раз, то это свойство не имеет смысла. Не наследуется.</p>
<table border="1" cellspacing="0" cellpadding="0" width="623">
  <tr>
    <th width="131" valign="top">Значения: </th>
    <th width="492" valign="top">Описание</th>
  </tr>
  <tr>
    <td width="131" valign="top"><p>alternate</p></td>
    <td width="492" valign="top"><p>Анимация проигрывается с начала до    конца, затем в обратном направлении.</p></td>
  </tr>
  <tr>
    <td width="131" valign="top"><p>alternate-reverse</p></td>
    <td width="492" valign="top"><p>Анимация проигрывается с конца до    начала, затем в обратном направлении.</p></td>
  </tr>
  <tr>
    <td width="131" valign="top"><p>normal</p></td>
    <td width="492" valign="top"><p>Значение по умолчанию, анимация    проигрывается в обычном направлении, с начала и до конца.</p></td>
  </tr>
  <tr>
    <td width="131" valign="top"><p>reverse</p></td>
    <td width="492" valign="top"><p>Анимация проигрывается с конца.</p></td>
  </tr>
  <tr>
    <td width="131" valign="top"><p>initial</p></td>
    <td width="492" valign="top"><p>Устанавливает значение свойства в    значение по умолчанию.</p></td>
  </tr>
  <tr>
    <td width="131" valign="top"><p>inherit</p></td>
    <td width="492" valign="top"><p>Наследует значение свойства от    родительского элемента.</p></td>
  </tr>
</table>
<p>Синтаксис</p>
<xmp id="scriptHTML">
      -webkit-animation-direction:    alternate; 
      animation-direction:    alternate; 
</xmp>

<p> Пример анимаии </p>
<div class="demo clearfix">
<div id="wrap8"></div>
<div id="wrap9"></div>
<div id="wrap10"></div>
</div>

<h2>Проигрывание анимации  animation-play-state </h2>
<p>Свойство управляет проигрыванием и остановкой анимации.  Остановка анимации внутри цикла возможна через использование этого свойства в  скрипте JavaScript. Также можно останавливать анимацию при наведении курсора  мыши на объект — состояние :hover. Не наследуется.</p>
<table border="1" cellspacing="0" cellpadding="0" width="623">
  <tr>
    <th width="131" valign="top">Значения: </th>
    <th width="492" valign="top">Описание</th>
  </tr>
  <tr>
    <td width="131" valign="top"><p>paused</p></td>
    <td width="492" valign="top"><p>Останавливает анимацию.</p></td>
  </tr>
  <tr>
    <td width="131" valign="top"><p>running</p></td>
    <td width="492" valign="top"><p>Значение по умолчанию, означает проигрывание анимации.</p></td>
  </tr>
  <tr>
    <td width="131" valign="top"><p>initial</p></td>
    <td width="492" valign="top"><p>Устанавливает значение свойства в значение по умолчанию.</p></td>
  </tr>
  <tr>
    <td width="131" valign="top"><p>inherit</p></td>
    <td width="492" valign="top"><p>Наследует значение свойства от родительского элемента.</p></td>
  </tr>
</table>
<p>Синтаксис:</p>
<xmp id="scriptHTML">
      -webkit-animation-play-state:    paused;
      animation-play-state:    paused; 
</xmp>



<h2>Состояние элемента до и после воспроизведения анимации animation-fill-mode</h2>
<p>Свойство определяет порядок применения определенных в  @keyframes стилей к объекту. Не наследуется.</p>
<table border="1" cellspacing="0" cellpadding="0" width="660">
  <tr>
    <th width="131" valign="top">Значения: </th>
    <th valign="top">Описание</th>
  </tr>
  <tr>
    <td width="131" valign="top"><p>none</p></td>
    <td valign="top"><p>Значение по умолчанию. Состояние элемента не меняется до или после    воспроизведения анимации.</p></td>
  </tr>
  <tr>
    <td width="131" valign="top"><p>forwards</p></td>
    <td valign="top"><p>Воспроизводит анимацию до последнего кадра по окончанию последнего    повтора и не отматывает ее к первоначальному состоянию.</p></td>
  </tr>
  <tr>
    <td width="131" valign="top"><p>backwards</p></td>
    <td valign="top"><p>Возвращает состояние элемента после загрузки страницы к первому кадру,    даже если установлена задержка&nbsp;animation-delay, и оставляет его там,    пока не начнется анимация.</p></td>
  </tr>
  <tr>
    <td width="131" valign="top"><p>both</p></td>
    <td valign="top"><p>Позволяет оставлять элемент в первом ключевом кадре до начала анимации    (игнорируя положительное значение задержки) и задерживать на последнем кадре    до конца последней анимации.</p></td>
  </tr>
  <tr>
    <td width="131" valign="top"><p>initial</p></td>
    <td valign="top"><p>Устанавливает значение свойства в значение по умолчанию.</p></td>
  </tr>
  <tr>
    <td width="131" valign="top"><p>inherit</p></td>
    <td valign="top"><p>Наследует значение свойства от родительского элемента.</p></td>
  </tr>
</table>
<p>Синтаксис:</p>
<xmp id="scriptHTML">
      -webkit-animation-fill-mode:    forwards; 
      animation-fill-mode:    forwards;
</xmp>


<h2>Множественные анимации</h2>
<p>Для одного элемента можно задавать несколько анимаций,  перечислив их названия через запятую:<br>
  Синтаксис:</p>
<xmp id="scriptHTML">
      animation:    shadow 1s ease-in-out 0.5s alternate, move 5s linear 2s;
</xmp>
<h2>Краткая запись анимации</h2>
<p>Все параметры воспроизведения анимации можно объединить в  одном свойстве — animation,  перечислив их через пробел: </p>
<xmp id="scriptHTML">
      animation:    animation-name animation-duration animation-timing-function animation-delay    
      animation-iteration-count animation-direction; 
</xmp>      
<p>&nbsp;</p>
<h1>Технология рисования canvas</h1>

<h3>Текст</h3>
<p>Следующие свойства  текста доступны для объекта контекста:</p>
<ul>
  <li>font:  Определяет шрифт текста, так же как свойство font-family в CSS)</li>
  <li>textAlign: Определяет горизонтальное выравнивание текста. Допустимые значения:  start, end, left, right, center. Значение по умолчанию: start.</li>
  <li>textBaseline: Определяет вертикальное выравнивание  текста. Допустимые значения: top, hanging, middle, alphabetic, ideographic,  bottom. Значение по умолчанию: alphabetic.</li>
</ul>
<p>Существуют два метода  для вывода текста: fillText  и strokeText. Первый  отрисовывает текст, заполняя его заливкой стиля fillStyle, другой рисует обводку текста, используя стиль  strokeStyle. Оба метода  принимают три аргумента: собственно текст и координаты (x,y),  в которых его необходимо вывести. Также существует четвертый необязательный  аргумент — максимальная ширина. Этот аргумент необходим для умещения текста в  заданную ширину.</p>
<p> Свойства выравнивания  текста влияют на позиционирование текста относительно координат его вывода (x,y).<br>
  Пример вывода текста:</p>
<xmp id="scriptHTML">
<canvas id="myCanvas6" width="300" height="250">
  <p>&nbsp;</p>
  <p>Альтернативное содержимое, которое будет показано, если браузер не поддерживает Canvas. 
    В данном случае можно написать сообщение «Ваш браузер не поддерживает CANVAS» </p>
</canvas>

<script>
    var canvas = document.getElementById("myCanvas6");
    var context = canvas.getContext("2d");
 
context.fillStyle = '#00f';
context.font = 'italic 30px sans-serif';
context.textBaseline = 'top';
context.fillText ('Пример вывода текста с заливкой', 0, 0);
context.font = 'bold 30px sans-serif';
context.strokeText('Пример вывода текста без заливки', 0, 50);


</script>

</xmp>  

<canvas id="myCanvas6" width="600" height="150">
  <p>Альтернативное содержимое, которое будет показано, если браузер не поддерживает Canvas. 
    В данном случае можно написать сообщение «Ваш браузер не поддерживает CANVAS» </p>
</canvas>

<script>
    var canvas = document.getElementById("myCanvas6");
    var context6 = canvas.getContext("2d");
 
context6.fillStyle = '#00f';
context6.font = 'italic 30px sans-serif';
context6.textBaseline = 'top';
context6.fillText ('Пример вывода текста с заливкой', 0, 0);
context6.font = 'bold 30px sans-serif';
context6.strokeText('Пример вывода текста без заливки', 0, 50);


</script>
  
<h3>Тени</h3>
<p>Shadow API предоставляет четыре свойства:</p>
<ul>
  <li>shadowColor: Определяет цвет тени. Значения допустимы в том же формате, что и в CSS.</li>
  <li>shadowBlur: Определяет степень размытия тени в пикселях. Эффект очень похож на  гауссово размытие в Photoshop.</li>
  <li>shadowOffsetX и shadowOffsetY: Определяет  сдвиг тени в пикселях (x, y).</li>
</ul>
<xmp id="scriptHTML">
<canvas id="myCanvas7" width="600" height="150">
  <p>Альтернативное содержимое, которое будет показано, если браузер не поддерживает Canvas. 
    В данном случае можно написать сообщение «Ваш браузер не поддерживает CANVAS» </p>
</canvas>

<script>
    var canvas = document.getElementById("myCanvas7");
    var context7 = canvas.getContext("2d");
 
	context7.shadowOffsetX = 5;
	context7.shadowOffsetY = 5;
	context7.shadowBlur = 4;
	context7.shadowColor = 'rgba(255, 0, 0, 0.5)';
	context7.fillStyle = '#652';
	context7.fillRect(20, 20, 150, 100);

</script>
</xmp>

<canvas id="myCanvas7" width="600" height="150">
  <p>Альтернативное содержимое, которое будет показано, если браузер не поддерживает Canvas. 
    В данном случае можно написать сообщение «Ваш браузер не поддерживает CANVAS» </p>
</canvas>

<script>
    var canvas = document.getElementById("myCanvas7");
    var context7 = canvas.getContext("2d");
 
	context7.shadowOffsetX = 15;
	context7.shadowOffsetY = 5;
	context7.shadowBlur = 44;
	context7.shadowColor = 'rgba(255, 0, 0, 0.5)';
	context7.fillStyle = '#652';
	context7.fillRect(20, 20, 150, 100);

</script>

<h3>Градиенты</h3>
<p>Свойства fillStyle и  strokeStyle также могут иметь объекты CanvasGradient вместо обычных цветов CSS  — это позволяет использовать градиенты для линий и заливок.</p>
<p> Для создания объектов  CanvasGradient можно использовать два метода: createLinearGradient и  createRadialGradient. Первый метод создает линейный градиент, а второй —  радиальный градиент.</p>
<p> Как только создан  объект градиента, можно добавлять в него цвета с помощью метода addColorStop.</p>

<xmp id="scriptHTML">
<canvas id="myCanvas8" width="600" height="220">
  <p>Альтернативное содержимое, которое будет показано, если браузер не поддерживает Canvas. 
    В данном случае можно написать сообщение «Ваш браузер не поддерживает CANVAS» </p>
</canvas>

<script>
var canvas = document.getElementById("myCanvas8");
var context8 = canvas.getContext("2d");
 
// Нужно указать начальные и конечные координаты (x,y) градиента
var gradient1 = context8.createLinearGradient(0, 0, 100, 100);

// Теперь можно добавлять цвета в градиент
// Первый градиент определяет позицию для цвета в градиенте.
// Допустимы значения от 0 (начало градиента) до 1 (конец градиента).
gradient1.addColorStop(0, '#f00'); // красный
gradient1.addColorStop(0.5, '#ff0'); // желтый
gradient1.addColorStop(1, '#00f'); // синий
context8.fillStyle = gradient1;
context8.fillRect(20, 20, 150, 100);

</script>
</xmp>
<canvas id="myCanvas8" width="600" height="220">
  <p>Альтернативное содержимое, которое будет показано, если браузер не поддерживает Canvas. 
    В данном случае можно написать сообщение «Ваш браузер не поддерживает CANVAS» </p>
</canvas>

<script>
    var canvas = document.getElementById("myCanvas8");
    var context8 = canvas.getContext("2d");
 
	// Нужно указать начальные и конечные координаты (x,y) градиента
var gradient1 = context8.createLinearGradient(0, 0, 100, 100);

// Теперь можно добавлять цвета в градиент
// Первый градиент определяет позицию для цвета в градиенте.
// Допустимы значения от 0 (начало градиента) до 1 (конец градиента).
gradient1.addColorStop(0, '#f00'); // красный
gradient1.addColorStop(0.5, '#ff0'); // желтый
gradient1.addColorStop(1, '#00f'); // синий
context8.fillStyle = gradient1;
context8.fillRect(20, 20, 150, 100);

</script>

<p>&nbsp;</p>
</div>
<footer>
<p> HTML5&amp;CSS. Профессиональная веб-разработка. Уровень 2.  </p>
<p> Все права защищены. Использование материалов сайта только со ссылкой на первоисточник </p>
</footer>
</body>
</html>
